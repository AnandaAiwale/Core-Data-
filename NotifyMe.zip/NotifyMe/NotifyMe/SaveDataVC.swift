//
//  SaveDataVC.swift
//  NotifyMe
//
//  Created by King on 21/05/18.
//  Copyright © 2018 AAA. All rights reserved.
//

import UIKit
import CoreData
class SaveDataVC: UIViewController {
    
    @IBOutlet var firstName: UITextField!
    @IBOutlet var LastName: UITextField!
    @IBOutlet var DateTime: UITextField!
    @IBOutlet var butAdd: UIButton!
    @IBOutlet var Delete: UIButton!
    @IBOutlet var update: UIButton!
    @IBOutlet var save: UIButton!
    var Fname:String?
    var LName:String?
    var dateT:String?
    var index:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if index == nil{
            Delete.isHidden = true
            update.isHidden = true
        }else{
            Delete.isHidden = false
            update.isHidden = false
            firstName.text = Fname
            LastName.text = LName
            DateTime.text = dateT
        }
        
    }
        

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Savedate(_ sender: Any) {
        if firstName.text != "" && LastName.text != "" && DateTime.text != "" {
        let fname =  firstName.text
        let lname = LastName.text
        let data = DateTime.text
        let dB =  NSEntityDescription.insertNewObject(forEntityName: "Information", into: app.getContext()) as! Information
        dB.firstName = fname
        dB.lastName = lname
        dB.time = data
        app.saveContext()
         firstName.text = ""
         LastName.text = ""
         DateTime.text  = ""
            }
        //self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func UpdateRecods(_ sender: Any) {
    let fetchRequest:NSFetchRequest<Information> =  Information.fetchRequest()
        do{
            let result  = try app.getContext().fetch(fetchRequest)
            var  dataR = result as [Information]
            if firstName.text != "" {
                 dataR[index!].setValue(firstName.text, forKey: "firstName")
            }
            if LastName.text != "" {
                 dataR[index!].setValue(LastName.text, forKey: "lastName")
            }
            if DateTime.text != "" {
                 dataR[index!].setValue(DateTime.text, forKey: "time")
               
            }
            app.saveContext()
            }catch{
            print(error.localizedDescription)
        }
        self.navigationController?.popViewController(animated: true)
        }
    
    @IBAction func AddressRecods(_ sender: Any) {
        firstName.text = ""
        LastName.text = ""
        DateTime.text  = ""
        }
    @IBAction func DeleteRecods(_ sender: Any) {
        do{
            var arar:[NSManagedObject] = []
            let result = NSFetchRequest<NSFetchRequestResult>(entityName: "Information")
            let resultt  = try app.getContext().fetch(result)
            for items in resultt as! [NSManagedObject]{
                arar.append(items)
            }
            let delet = app.getContext()
            delet.delete(arar[index!])
            app.saveContext()
        }catch{
            
        }
        
        
//        print(index ?? 0000000)
//        let fetchRequest:NSFetchRequest<Information> =  Information.fetchRequest()
//        do{
//            let result  = try app.getContext().fetch(fetchRequest)
//            var  dataR = result as [Information]
//            if index! >= 0 {
//            dataR.remove(at: index!)
//            app.saveContext()
//            }
//        }catch{
//            print(error.localizedDescription)
//        }
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func BackVC(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

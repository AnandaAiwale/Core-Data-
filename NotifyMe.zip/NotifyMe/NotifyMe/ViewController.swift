//
//  ViewController.swift
//  NotifyMe
//
//  Created by King on 21/05/18.
//  Copyright © 2018 AAA. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet var InfoDisplayData: UITableView!
    var fname:[String] = []
    var lName:[String] = []
    var Time:[String] = []
    var DataArray:[Information] = []
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func getById(id: NSManagedObjectID) -> Information {
        let idn = app.getContext()
        return (idn.object(with: id) as? Information)!
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DataArray.removeAll()
        let fetchRequest:NSFetchRequest<Information> =  Information.fetchRequest()
        do{
         let result  = try app.getContext().fetch(fetchRequest)
            for dataR in result as [Information] {
                DataArray.append(dataR)
            }
        }catch{
            print(error.localizedDescription)
        }
        InfoDisplayData.reloadData()
    }
    
    
//    func UpdateRecoder()  {
//
//        let fetchRequest:NSFetchRequest<Information> =  Information.fetchRequest()
//        do{
//            let result  = try app.getContext().fetch(fetchRequest)
//            for dataR in result as [Information] {
//                dataR.setValue("Ajit", forKey: "firstName")
//                //DataArray.append(dataR)
//            }
//        }catch{
//            print(error.localizedDescription)
//        }
//
//
//    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  DataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 105
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = InfoDisplayData.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        cell.labFirstName.text = "First Name = " + DataArray[indexPath.row].firstName!
        cell.LastName.text  = "Last Name = " + DataArray[indexPath.row].lastName!
        cell.labTime.text = "Age = " + DataArray[indexPath.row].time!
        return cell
    }
    
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier:"SaveDataVC") as! SaveDataVC
        vc.index = indexPath.row
        if let n = DataArray[indexPath.row].firstName, let l = DataArray[indexPath.row].lastName,let D = DataArray[indexPath.row].time{
        vc.Fname = n
        vc.LName = l
        vc.dateT = D
        self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func AddData(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier:"SaveDataVC") as! SaveDataVC
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
}


//
//  Information+CoreDataProperties.swift
//  NotifyMe
//
//  Created by King on 21/05/18.
//  Copyright © 2018 AAA. All rights reserved.
//
//

import Foundation
import CoreData


extension Information {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Information> {
        return NSFetchRequest<Information>(entityName: "Information")
    }

    @NSManaged public var firstName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var time: String?

}

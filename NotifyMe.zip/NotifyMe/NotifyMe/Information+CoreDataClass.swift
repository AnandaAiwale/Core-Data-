//
//  Information+CoreDataClass.swift
//  NotifyMe
//
//  Created by King on 21/05/18.
//  Copyright © 2018 AAA. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Information)
public class Information: NSManagedObject {

}
